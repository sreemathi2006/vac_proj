const express = require("express");

const router = express.Router();

const protect = require("../middleware/authmiddleware");

const {
    createBooking,
    getMyBookings,
    deleteBooking
} = require("../controllers/bookingcontroller");


router.post("/", protect, createBooking);

router.get("/my", protect, getMyBookings);

router.delete("/:id", protect, deleteBooking);


module.exports = router;