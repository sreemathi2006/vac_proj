const User = require("../models/User");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");


// ==========================================
// REGISTER
// ==========================================

const register = async (req, res) => {

    try {

        const { name, email, password } = req.body;

        // Check existing user
        const existingUser = await User.findOne({ email });

        if (existingUser) {

            return res.status(400).json({
                message: "User already exists"
            });

        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user
         const user = await User.create({
              name: name,
              email: email,
              password: hashedPassword
});


        // ==========================================
        // EMAIL CONFIGURATION
        // ==========================================

        const transporter = nodemailer.createTransport({

            service: "gmail",

            auth: {
                user: process.env.EMAIL_USER,
                pass: process.env.EMAIL_PASS
            },

            tls: {
                rejectUnauthorized: false
            }

        });


        // ==========================================
        // SEND WELCOME EMAIL
        // ==========================================

        await transporter.sendMail({

            from: process.env.EMAIL_USER,

            to: email,

            subject: "🎉 Welcome to DriveX!",

            text: `Hello ${name},

Welcome to DriveX!

Your account has been successfully created.

You can now log in to your DriveX account and book your vehicle.

Thank you for joining DriveX!

Regards,
DriveX Team
Vehicle Rental and Booking Management System`

        });


        // ==========================================
        // SUCCESS RESPONSE
        // ==========================================

        res.status(201).json({

            message: "Registration successful. Welcome email sent!",

            user: {
                id: user._id,
                name: user.name,
                email: user.email
            }

        });


    } catch (error) {

        console.error("Registration Error:", error);

        res.status(500).json({

            message: "Registration failed",
            error: error.message

        });

    }

};


// ==========================================
// LOGIN
// ==========================================

const login = async (req, res) => {

    try {

        const { email, password } = req.body;

        const user = await User.findOne({ email });


        if (!user) {

            return res.status(401).json({
                message: "Invalid email or password"
            });

        }


        const isMatch = await bcrypt.compare(
            password,
            user.password
        );


        if (!isMatch) {

            return res.status(401).json({
                message: "Invalid email or password"
            });

        }


        const token = jwt.sign(

            { id: user._id },

            process.env.JWT_SECRET,

            { expiresIn: "1d" }

        );


        res.json({

            message: "Login successful",

            token: token,

            user: {

                id: user._id,
                name: user.name,
                email: user.email

            }

        });


    } catch (error) {

        console.error("Login Error:", error);

        res.status(500).json({
            message: "Server error"
        });

    }

};


// ==========================================
// EXPORT
// ==========================================

module.exports = {
    register,
    login
};