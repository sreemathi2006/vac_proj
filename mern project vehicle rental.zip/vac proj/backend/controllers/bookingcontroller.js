const Booking = require("../models/Booking");

// Create Booking
const createBooking = async (req, res) => {
    try {
        const {
            vehicle,
            pickupDate,
            returnDate,
            location
        } = req.body;

        const booking = await Booking.create({
            user: req.user.id,
            vehicle,
            pickupDate,
            returnDate,
            location
        });

        res.status(201).json({
            message: "Booking confirmed successfully!",
            booking
        });

    } catch (error) {
        console.error("Booking Error:", error);

        res.status(500).json({
            message: "Booking failed",
            error: error.message
        });
    }
};


// Get My Bookings
const getMyBookings = async (req, res) => {
    try {
        const bookings = await Booking.find({
            user: req.user.id,
            status: { $ne: "Cancelled" }
        }).sort({ createdAt: -1 });

        res.json(bookings);

    } catch (error) {
        console.error("Get Bookings Error:", error);

        res.status(500).json({
            message: "Unable to get bookings"
        });
    }
};


// Delete Booking
const deleteBooking = async (req, res) => {
    try {
        const booking = await Booking.findOne({
            _id: req.params.id,
            user: req.user.id
        });

        if (!booking) {
            return res.status(404).json({
                message: "Booking not found"
            });
        }

        await Booking.findByIdAndDelete(req.params.id);

        res.json({
            message: "Booking cancelled successfully!"
        });

    } catch (error) {
        console.error("Delete Booking Error:", error);

        res.status(500).json({
            message: "Unable to cancel booking"
        });
    }
};


module.exports = {
    createBooking,
    getMyBookings,
    deleteBooking
};