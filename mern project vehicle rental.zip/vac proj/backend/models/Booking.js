const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },

        vehicle: {
            type: String,
            required: true
        },

        pickupDate: {
            type: Date,
            required: true
        },

        returnDate: {
            type: Date,
            required: true
        },

        location: {
            type: String,
            required: true
        },

        status: {
            type: String,
            default: "Confirmed"
        }
    },
    {
        timestamps: true
    }
);

module.exports = mongoose.model("Booking", bookingSchema);