console.log("DriveX Frontend Loaded");


// =====================================================
// REGISTER
// =====================================================

const registerForm = document.getElementById("registerForm");

if (registerForm) {

    registerForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword =
            document.getElementById("confirmPassword").value;


        // Name validation
        if (name.length < 3) {
            alert("Name must contain at least 3 characters.");
            return;
        }


        // Email validation
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(email)) {
            alert("Please enter a valid email address.");
            return;
        }


        // Password validation
        if (password.length < 6) {
            alert("Password must contain at least 6 characters.");
            return;
        }


        // Confirm password
        if (password !== confirmPassword) {
            alert("Passwords do not match!");
            return;
        }


        try {

            const response = await fetch(
                "http://localhost:5000/api/auth/register",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        name: name,
                        email: email,
                        password: password
                    })
                }
            );


            const data = await response.json();


            if (response.ok) {

                alert(
                    "Registration successful! Welcome email sent."
                );

                window.location.href = "login.html";

            } else {

                alert(
                    data.message || "Registration failed."
                );
            }


        } catch (error) {

            console.error("Registration Error:", error);

            alert(
                "Backend connection failed! Make sure backend is running."
            );
        }

    });

}



// =====================================================
// LOGIN
// =====================================================

const loginForm = document.getElementById("loginForm");

if (loginForm) {

    loginForm.addEventListener("submit", async function (event) {

        event.preventDefault();


        const email =
            document.getElementById("email").value.trim();

        const password =
            document.getElementById("password").value;


        try {

            const response = await fetch(
                "http://localhost:5000/api/auth/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                }
            );


            const data = await response.json();


            if (response.ok) {

                // Save login token
                localStorage.setItem(
                    "token",
                    data.token
                );


                // Save user details
                localStorage.setItem(
                    "user",
                    JSON.stringify(data.user)
                );


                // Remember email
                localStorage.setItem(
                    "lastLoginEmail",
                    email
                );


                alert("Login successful!");


                window.location.href = "index.html";

            } else {

                alert(
                    data.message || "Login failed."
                );
            }


        } catch (error) {

            console.error("Login Error:", error);

            alert(
                "Backend connection failed! Make sure backend is running."
            );
        }

    });

}



// =====================================================
// AUTO-FILL LAST LOGIN EMAIL
// =====================================================

const loginEmailInput =
    document.getElementById("email");

if (
    loginEmailInput &&
    window.location.pathname.includes("login")
) {

    const lastEmail =
        localStorage.getItem("lastLoginEmail");

    if (lastEmail) {

        loginEmailInput.value = lastEmail;

    }

}



// =====================================================
// PROFILE
// =====================================================

function toggleProfile() {

    const dropdown =
        document.getElementById("profileDropdown");

    if (dropdown) {

        dropdown.classList.toggle("show");

    }

}



// =====================================================
// DISPLAY LOGGED-IN USER
// =====================================================

const savedUser =
    localStorage.getItem("user");

if (savedUser) {

    try {

        const user =
            JSON.parse(savedUser);


        const profileName =
            document.getElementById("profileName");

        const profileEmail =
            document.getElementById("profileEmail");


        if (profileName) {

            profileName.textContent =
                user.name || "User";

        }


        if (profileEmail) {

            profileEmail.textContent =
                user.email || "";

        }


    } catch (error) {

        console.error(
            "Profile Error:",
            error
        );

    }

}



// =====================================================
// LOGOUT
// =====================================================

function logout() {

    const savedUser =
        localStorage.getItem("user");


    // Remember email
    if (savedUser) {

        try {

            const user =
                JSON.parse(savedUser);

            if (user.email) {

                localStorage.setItem(
                    "lastLoginEmail",
                    user.email
                );

            }

        } catch (error) {

            console.error(
                "Logout Error:",
                error
            );

        }

    }


    // Remove only login session
    localStorage.removeItem("token");

    localStorage.removeItem("user");


    alert("Logged out successfully!");


    window.location.href =
        "login.html";

}



// =====================================================
// CREATE BOOKING
// =====================================================

const bookingForm =
    document.getElementById("bookingForm");

if (bookingForm) {

    bookingForm.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            const token =
                localStorage.getItem("token");


            if (!token) {

                alert("Please login first.");

                window.location.href =
                    "login.html";

                return;
            }


            const vehicle =
                document.getElementById("vehicle").value;

            const pickupDate =
                document.getElementById("pickupDate").value;

            const returnDate =
                document.getElementById("returnDate").value;

            const location =
                document.getElementById("location").value.trim();


            // Date validation
            if (returnDate < pickupDate) {

                alert(
                    "Return date cannot be before pickup date."
                );

                return;
            }


            try {

                const response = await fetch(
                    "http://localhost:5000/api/bookings",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json",
                            "Authorization":
                                "Bearer " + token
                        },

                        body: JSON.stringify({

                            vehicle: vehicle,

                            pickupDate: pickupDate,

                            returnDate: returnDate,

                            location: location

                        })
                    }
                );


                const data =
                    await response.json();


                if (!response.ok) {

                    alert(
                        data.message ||
                        "Booking failed."
                    );

                    return;
                }


                alert(
                    "Booking confirmed successfully! 🚗"
                );


                bookingForm.reset();


                window.location.href =
                    "mybooking.html";


            } catch (error) {

                console.error(
                    "Booking Error:",
                    error
                );

                alert(
                    "Unable to create booking. Please check your backend."
                );
            }

        }
    );

}



// =====================================================
// LOAD MY BOOKINGS
// =====================================================

async function loadMyBookings() {

    const bookingList =
        document.getElementById("bookingList");


    // If this is not My Bookings page
    if (!bookingList) {

        return;
    }


    const token =
        localStorage.getItem("token");


    // User not logged in
    if (!token) {

        bookingList.innerHTML = `
            <div class="no-bookings">
                <h3>Please Login</h3>
                <p>Login to view your bookings.</p>
                <a href="login.html">
                    Login
                </a>
            </div>
        `;

        return;
    }


    try {

        const response = await fetch(
            "http://localhost:5000/api/bookings/my",
            {
                method: "GET",

                headers: {
                    "Authorization":
                        "Bearer " + token
                }
            }
        );


        const bookings =
            await response.json();


        if (!response.ok) {

            throw new Error(
                bookings.message ||
                "Unable to load bookings"
            );
        }


        // No bookings
        if (
            !Array.isArray(bookings) ||
            bookings.length === 0
        ) {

            bookingList.innerHTML = `
                <div class="no-bookings">
                    <h3>No Bookings Yet 🚗</h3>

                    <p>
                        You haven't booked any vehicle yet.
                    </p>

                    <a href="booking.html">
                        Book a Vehicle
                    </a>
                </div>
            `;

            return;
        }


        // Clear loading message
        bookingList.innerHTML = "";


        // Display every booking
        bookings.forEach(function (booking) {

            const card =
                document.createElement("div");


            card.className =
                "booking-card";


            card.innerHTML = `

                <h3>
                    🚗 ${booking.vehicle}
                </h3>

                <p>
                    <strong>Pickup Date:</strong>
                    ${new Date(
                        booking.pickupDate
                    ).toLocaleDateString()}
                </p>

                <p>
                    <strong>Return Date:</strong>
                    ${new Date(
                        booking.returnDate
                    ).toLocaleDateString()}
                </p>

                <p>
                    <strong>Location:</strong>
                    ${booking.location}
                </p>

                <p>
                    <strong>Status:</strong>
                    ${booking.status}
                </p>

                <button
                    class="cancel-btn"
                    onclick="cancelBooking('${booking._id}')">

                    Cancel Booking

                </button>
            `;


            bookingList.appendChild(card);

        });


    } catch (error) {

        console.error(
            "My Bookings Error:",
            error
        );


        bookingList.innerHTML = `
            <div class="no-bookings">
                <h3>Unable to load bookings</h3>

                <p>
                    Please check whether the backend is running.
                </p>
            </div>
        `;
    }

}



// =====================================================
// CANCEL BOOKING
// =====================================================

async function cancelBooking(bookingId) {

    const confirmation =
        confirm(
            "Are you sure you want to cancel this booking?"
        );


    if (!confirmation) {

        return;
    }


    const token =
        localStorage.getItem("token");


    if (!token) {

        alert("Please login first.");

        window.location.href =
            "login.html";

        return;
    }


    try {

        const response = await fetch(

            `http://localhost:5000/api/bookings/${bookingId}`,

            {
                method: "DELETE",

                headers: {
                    "Authorization":
                        "Bearer " + token
                }
            }

        );


        const data =
            await response.json();


        if (!response.ok) {

            alert(
                data.message ||
                "Unable to cancel booking."
            );

            return;
        }


        alert(
            "Booking cancelled successfully! 🚗"
        );


        // Reload bookings from MongoDB
        await loadMyBookings();


    } catch (error) {

        console.error(
            "Cancel Booking Error:",
            error
        );


        alert(
            "Unable to cancel booking."
        );
    }

}



// =====================================================
// PAGE LOAD
// =====================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        // Load My Bookings only
        // when bookingList exists
        loadMyBookings();

    }
);